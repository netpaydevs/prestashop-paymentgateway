<?php

class NetpayPrestashopConfirmpaymentModuleFrontController extends ModuleFrontController{
    
    public function initContent(){
        error_log("NetpayPrestashopValidationModuleFrontController -> initContent() All_Values: ". json_encode(Tools::getAllValues()), 0);
        
        $arrayValues = Tools::getAllValues();
        
        unset($arrayValues['module']); unset($arrayValues['controller']); unset($arrayValues['fc']);
        
        $arrayValues['CardNumber'] = str_replace(' ', '', $arrayValues['CardNumber']);
        $arrayValues['CardNumber'] = str_replace('*', '-', $arrayValues['CardNumber']);
        
        $urlOrderConfirm = Tools::getHttpHost(true).__PS_BASE_URI__.'index.php?controller=order-confirmation&'.http_build_query($arrayValues);
        
        error_log("NetpayPrestashopValidationModuleFrontController -> initContent() Http build query : ". http_build_query($arrayValues,null,null,PHP_QUERY_RFC3986), 0);
        error_log("NetpayPrestashopValidationModuleFrontController -> initContent() UrlConfirm: ". $urlOrderConfirm, 0);
        
        $this->context->smarty->assign(array('urlConfirm' => $urlOrderConfirm));
       
        $this->setTemplate('confirm_payment.js.tpl');
    } 
	
    public function postProcess(){
     
    }
}