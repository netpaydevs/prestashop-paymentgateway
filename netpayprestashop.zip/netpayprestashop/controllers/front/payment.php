<?php

class NetPayPrestashopPaymentModuleFrontController extends ModuleFrontController
{
	public $ssl = true;
	public $display_column_left = false;
        private $module_name;

        /**
	 * @see FrontController::initContent()
	 */
	public function initContent(){
            error_log("netpayprestashoppaymentModuleFrontController -> initContent() Configuration Name: ". Configuration::get('NETPAY_PRESTASHOP_NAME'), 0);
            
            $this->module_name = strval(Configuration::get('NETPAY_PRESTASHOP_NAME'));
            
            if (!$this->module_name || empty($this->module_name) || !Validate::isGenericName($this->module_name)){
                //$output .= $this->displayError($this->l('Invalid Configuration value')); 
            }else{
                
                parent::initContent();
                parent::setMedia();
                
                $cart = $this->context->cart;
                $address = new Address(intval($cart->id_address_invoice));
                $this->addCSS(_MODULE_DIR_ . $this->module_name . '/views/css/payment_execute.css', 'all');
                
                error_log("netpayprestashoppaymentModuleFrontController -> initContent(): " . json_encode($cart), 0);
                error_log("netpayprestashoppaymentModuleFrontController -> initContent() address: " . json_encode(new Address(intval($cart->id_address_delivery))), 0);
                
                if (!$this->module->checkCurrency($cart))
                    Tools::redirect('index.php?controller=order');
                    
                    $this->context->smarty->assign(array(
                        'nbProducts' => $cart->nbProducts(),
                        'cust_currency' => $cart->id_currency,
                        'currencies' => $this->module->getCurrency((int)$cart->id_currency),
                        'total' => $cart->getOrderTotal(true, Cart::BOTH),
                        'isoCode' => $this->context->language->iso_code,
                        'address' =>  $address,
                        'state'=>StateCore::getNameById($address->id_state),
                        'this_path' => $this->module->getPathUri(),
                        'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/'
                  ));
                  
                    $this->setTemplate('payment_execute.tpl');
            }

	}
}
