<?php

class NetpayPrestashopProcesspaymentModuleFrontController extends ModuleFrontController{
    private $urlSecurePayment = null;
    private $module_name;
    
    public function postProcess(){
        
        $cart = $this->context->cart;
        $this->module_name = strval(Configuration::get('NETPAY_PRESTASHOP_NAME'));

        error_log("NetpayPrestashopProcesspaymentModuleFrontController -> postProcess()". json_encode($cart), 0);
        
	if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
            Tools::redirect('index.php?controller=order&step=1');

            // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
            $authorized = false;
            foreach (Module::getPaymentModules() as $module)
                if ($module['name'] == 'netpayprestashop'){
                    $authorized = true;
                    break;
		}

            if (!$authorized)
                die($this->module->l('This payment method is not available.', 'validation'));

            $customer = new Customer($cart->id_customer);

            if (!Validate::isLoadedObject($customer))
                Tools::redirect('index.php?controller=order&step=1');

            $currency = $this->context->currency;
            $total = (float)$cart->getOrderTotal(true, Cart::BOTH);

            $mailVars =	array(
			'{cheque_name}' => Configuration::get('CHEQUE_NAME'),
			'{cheque_address}' => Configuration::get('CHEQUE_ADDRESS'),
			'{cheque_address_html}' => str_replace("\n", '<br />', Configuration::get('CHEQUE_ADDRESS')));

            if($this->module->validateOrder((int)$cart->id, (int)Configuration::get('PENDING_NETPAY_PAYMENT'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key));
                $this->urlSecurePayment = $this->buildUrlSecurePayment($cart);
    }
    
    public function initContent(){
        error_log("NetpayPrestashopProcesspaymentModuleFrontController -> initContent() Configuration Name: ". Configuration::get('NETPAY_PRESTASHOP_NAME') . "Url Secure Payment: ".$this->urlSecurePayment, 0);
        $this->context->smarty->assign(array(
                        'urlSecurePayment' => $this->urlSecurePayment,
                        'nbProducts' => $this->context->cart->nbProducts()
                    ));
        
        $this->addCSS(_MODULE_DIR_ . $this->module_name . '/views/css/processpayment.css', 'all');
        $this->setTemplate('process_payment_execute.tpl');
    }
	
    
    private function buildUrlSecurePayment($cart){
        
        $address = new Address(intval($cart->id_address_invoice));
        $customer = new Customer($cart->id_customer);
        //$merchantResponseUrl = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]".'/index.php?controller=order-confirmation&id_cart='.(int)$cart->id.'&id_module='.(int)$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key;
        $merchantResponseUrl  = Tools::getHttpHost(true).__PS_BASE_URI__."module/netpayprestashop/confirmpayment?".'id_cart='.(int)$cart->id.'&id_module='.(int)$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key;
        $url = Configuration::get('PS_NETPAY_SECURE_PAYMENT');
        $total_amount = (float)$cart->getOrderTotal(true, Cart::BOTH);
        
        $extraParams = "OrderNumber=" . $this->module->currentOrderReference
                . "&MerchantResponseURL=" . base64_encode($merchantResponseUrl)
                . "&Amount=" . $total_amount
                . "&ConfigId=" . Configuration::get('PS_NETPAY_CONF_ID')
                . "&Operator=" . Configuration::get('PS_NETPAY_USER')
                . "&Channel=" . Configuration::get('PS_NETPAY_PASSWORD')
                . "&Currency=" . Configuration::get('PS_NETPAY_CURRENCY')
                . "&ZipCode=" . $address->postcode
                . "&Address=" . "$address->address1,$address->address2"
                . "&City=" . $address->city
                . "&State=" . StateCore::getNameById($address->id_state)
                . "&Email=" . $this->context->customer->email
                . "&SendEmail=true"
                . "&MSI3=" . ($total_amount  >= 300 && boolval(Configuration::get('MSI_3')) ? 1 : 0)
                . "&MSI6=" . ($total_amount  >= 600 && boolval(Configuration::get('MSI_6')) ? 1 : 0)
                . "&MSI9=" . ($total_amount  >= 900 && boolval(Configuration::get('MSI_9')) ? 1 : 0)
                . "&MSI12=" . ($total_amount  >= 1200 && boolval(Configuration::get('MSI_12')) ? 1 : 0)
                . "&WebHookResponse=WebSite";

        error_log("NetpayPrestashopProcesspaymentModuleFrontController -> buildUrlSecurePayment():  ". $url."?".$extraParams, 0);
        return $url . '?hash=' . base64_encode($extraParams);
    }
}