<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of netpayprestashop
 *
 * @author NetPay
 */

if (!defined('_PS_VERSION_'))
	exit;

class Netpayprestashop extends PaymentModule{
    
    public function __construct(){
        $this->name = 'netpayprestashop';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.2';
        $this->author = 'NetPay';
        $this->bootstrap = true;
        parent::__construct();
        $this->module_key = 'J18QT3MSD88WU32W1U3NFY2WQCNBW8S6';
        $this->displayName = $this->l('NetPay Prestashop');
        $this->description = $this->l('Accept payments by Credit and Debit Card with NetPay (Visa, Mastercard, Amex)');
        $this->confirmUninstall = $this->l('Warning: all the NetPay transaction details in your database will be deleted. Are you sure you want uninstall this module?');
        $this->backward_error = $this->l('In order to work correctly in PrestaShop v1.4, this module requires backward compatibility module of at least v0.4.');
        
        if (!Configuration::get('NETPAY_PRESTASHOP_NAME')){
            $this->warning = $this->l('No name provided');
        }

        /*if (version_compare(_PS_VERSION_, '1.5', '<')) {
            require(_PS_MODULE_DIR_ . $this->name . '/compatibility/backward.php');
            $this->backward = true;
        } else {
            $this->backward = true;
        }*/
    }
    
    public function install(){
        error_log("netpayprestashop: install()", 0);

        if (!$this->backward && _PS_VERSION_ < 1.5) {
            $this->smarty->assign("error_message", $this->backward_error);
            echo $this->fetchTemplate("error.tpl");
            return false;
        }

        if (!parent::install() || !$this->__createNetPayAcceptedState()  || !$this->__createPendingNetPayState() || !$this->registerHook('payment') || !$this->registerHook('paymentReturn') || !$this->registerHook('leftColumn') || !$this->registerHook('header') || !Configuration::updateValue('NETPAY_PRESTASHOP_NAME',  $this->name) 
                                                        || !Configuration::updateValue('NETPAY_PRESTASHOP_VERSION',  $this->version)){
            return false;
        }
        
        $updateConfig = array(
            'PS_OS_CHEQUE' => 1,
            'PS_OS_PAYMENT' => 2,
            'PS_OS_PREPARATION' => 3,
            'PS_OS_SHIPPING' => 4,
            'PS_OS_DELIVERED' => 5,
            'PS_OS_CANCELED' => 6,
            'PS_OS_REFUND' => 7,
            'PS_OS_ERROR' => 8,
            'PS_OS_OUTOFSTOCK' => 9,
            'PS_OS_BANKWIRE' => 10,
            'PS_OS_PAYPAL' => 11,
            'PS_OS_WS_PAYMENT' => 12
            );

        foreach ($updateConfig as $u => $v) {
            if (!Configuration::get($u) || (int) Configuration::get($u) < 1) {
                if (defined('_' . $u . '_') && (int) constant('_' . $u . '_') > 0) {
                    Configuration::updateValue($u, constant('_' . $u . '_'));
                } else {
                    Configuration::updateValue($u, $v);
                }
            }
        }
        
        return true;
    }
    
    public function uninstall() {
        error_log("netpayprestashop: uninstall()", 0);

        if (!parent::uninstall() || !Configuration::deleteByName('NETPAY_PRESTASHOP_NAME') || !Configuration::deleteByName('NETPAY_PRESTASHOP_VERSION') || !Configuration::deleteByName('PS_NETPAY_USER')
                || !Configuration::deleteByName('PS_NETPAY_PASSWORD') || !Configuration::deleteByName('PS_NETPAY_CURRENCY') || !Configuration::deleteByName('PS_NETPAY_CONF_ID') 
                || !Configuration::deleteByName('PS_NETPAY_SECURE_PAYMENT') || !Configuration::deleteByName('PENDING_NETPAY_PAYMENT')  || !Configuration::deleteByName('ACCEPTED_NETPAY_PAYMENT')
                || !Configuration::deleteByName('MSI_3') || !Configuration::deleteByName('MSI_6') || !Configuration::deleteByName('MSI_9') || !Configuration::deleteByName('MSI_12')){
            return false;
        }
        return true;
    }
    
    public function getContent() {
        error_log("netpayprestashop -> getContent()", 0);
        $output = null;
        
        error_log("netpayprestashop -> getContent(): Tools Values: " . json_encode(Tools::getAllValues()), 0);
        error_log("netpayprestashop -> getContent(): Module name: " . Tools::getValue('configure'), 0);
        error_log("netpayprestashop -> getContent(): Submit: is submit -> " . Tools::isSubmit('submit' . $this->name) . " Submit Name->".'submit' . $this->name , 0);
        
        if (Tools::isSubmit('submit' . $this->name)) {         
            $module_name = strval(Tools::getValue('configure'));
            
            if (!$module_name || empty($module_name) || !Validate::isGenericName($module_name)){
                $output .= $this->displayError($this->l('Invalid Configuration value')); 
                
            }else {
                Configuration::updateValue('NETPAY_PRESTASHOP_NAME', $module_name);
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }
        
        if(Tools::isSubmit('submit_configure_values')){
            Configuration::updateValue('PS_NETPAY_USER', Tools::getValue('PS_NETPAY_USER'));
            Configuration::updateValue('PS_NETPAY_PASSWORD', Tools::getValue('PS_NETPAY_PASSWORD'));
            Configuration::updateValue('PS_NETPAY_CURRENCY', Tools::getValue('PS_NETPAY_CURRENCY'));
            Configuration::updateValue('PS_NETPAY_CONF_ID', Tools::getValue('PS_NETPAY_CONF_ID'));
            Configuration::updateValue('PS_NETPAY_SECURE_PAYMENT', Tools::getValue('PS_NETPAY_SECURE_PAYMENT'));
            Configuration::updateValue('MSI_3', Tools::getValue('MSI_3_ON'));
            Configuration::updateValue('MSI_6', Tools::getValue('MSI_6_ON'));
            Configuration::updateValue('MSI_9', Tools::getValue('MSI_9_ON'));
            Configuration::updateValue('MSI_12', Tools::getValue('MSI_12_ON'));
        }
      
        return $output . $this->displayForm();
    }
    
    public function displayForm() {
        // Get default language
        $default_lang = (int) Configuration::get('PS_LANG_DEFAULT');

        // Init Fields form array
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('NetPay Configuration'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('NetPay User'),
                    'name' => 'PS_NETPAY_USER',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('NetPay Password'),
                    'name' => 'PS_NETPAY_PASSWORD',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Currency'),
                    'name' => 'PS_NETPAY_CURRENCY',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Config ID'),
                    'name' => 'PS_NETPAY_CONF_ID',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('URL Secure Payment'),
                    'name' => 'PS_NETPAY_SECURE_PAYMENT',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'checkbox',
                    'name' => 'MSI_3',
                    'values' => array(
                        'query' => array(
                            array('id' => 'ON', 'name' => $this->l('3 Meses Sin Intereses'), 'val' => '1'),
                            ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ),
                array(
                    'type' => 'checkbox',
                    'name' => 'MSI_6',
                    'values' => array(
                        'query' => array(
                            array('id' => 'ON', 'name' => $this->l('6 Meses Sin Intereses'), 'val' => '1'),
                            ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ),
                array(
                    'type' => 'checkbox',
                    'name' => 'MSI_9',
                    'values' => array(
                        'query' => array(
                            array('id' => 'ON', 'name' => $this->l('9 Meses Sin Intereses'), 'val' => '1'),
                            ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ),
                array(
                    'type' => 'checkbox',
                    'name' => 'MSI_12',
                    'values' => array(
                        'query' => array(
                            array('id' => 'ON', 'name' => $this->l('12 Meses Sin Intereses'), 'val' => '1'),
                            ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );
        
        

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;        // false -> remove toolbar
        $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit' . '_configure_values';
        $helper->toolbar_btn = array(
            'save' =>
            array(
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name .
                '&token=' . Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' => array(
                'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            )
        );

        // Load current value
        $helper->fields_value['PS_NETPAY_USER'] = Configuration::get('PS_NETPAY_USER');
        $helper->fields_value['PS_NETPAY_PASSWORD'] = Configuration::get('PS_NETPAY_PASSWORD');
        $helper->fields_value['PS_NETPAY_CURRENCY'] = Configuration::get('PS_NETPAY_CURRENCY');
        $helper->fields_value['PS_NETPAY_CONF_ID'] = Configuration::get('PS_NETPAY_CONF_ID');
        $helper->fields_value['PS_NETPAY_SECURE_PAYMENT'] = Configuration::get('PS_NETPAY_SECURE_PAYMENT');
        $helper->fields_value['MSI_3_ON'] = Configuration::get('MSI_3');
        $helper->fields_value['MSI_6_ON'] = Configuration::get('MSI_6');
        $helper->fields_value['MSI_9_ON'] = Configuration::get('MSI_9');
        $helper->fields_value['MSI_12_ON'] = Configuration::get('MSI_12');

        return $helper->generateForm($fields_form);
    }
    
    public function hookPayment($params) {
        error_log("netpayprestashop -> hookPayment(): " . json_encode($params), 0);
        
        $this->context->controller->addCSS(_MODULE_DIR_.$this->name.'/views/css/netpayprestashop.css', 'all');
        
        if (!$this->active)
            return;
        if (!$this->checkCurrency($params['cart']))
            return;

        $this->smarty->assign(array(
            'this_path' => $this->_path,
            'this_path_netpayprestashop' => $this->_path,
            'this_path_ssl' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->name . '/'
        ));
        return $this->display(__FILE__, 'payment.tpl');
    }
    
    public function hookPaymentReturn($params) {
        error_log("netpayprestashop -> hookPaymentReturn()". json_encode($params), 0);
        error_log("netpayprestashop -> hookPaymentReturn() All Values: ". json_encode(Tools::getAllValues()), 0);
        
        if (!$this->active)
            return;

        $state = $params['objOrder']->getCurrentState();
        
        $responseCode= array_key_exists('ResponseCode', Tools::getAllValues()) ? (string)Tools::getValue('ResponseCode'):'-1';
      
        $customer = new Customer($params['objOrder']->id_customer);
        
        error_log("netpayprestashop -> hookPaymentReturn() status: ". $responseCode, 0);
        
        error_log("netpayprestashop -> hookPaymentReturn() customer: ". json_encode($customer), 0);
        
        if (in_array($state, array(Configuration::get('PENDING_NETPAY_PAYMENT')))) {
            
            $history = new OrderHistory();
            $history->id_order = (int) $params['objOrder']->id;
            
            if($responseCode == '00'){    
                $history->id_order_state = (int)Configuration::get('ACCEPTED_NETPAY_PAYMENT');
                $history->changeIdOrderState((int)Configuration::get('ACCEPTED_NETPAY_PAYMENT'), (int) $params['objOrder']->id);
                $history->add();
            }else{
                $history->id_order_state = (int) Configuration::get('PS_OS_CANCELED');
                $history->changeIdOrderState((int) Configuration::get('PS_OS_CANCELED'), (int) $params['objOrder']->id);
                $history->add();
            }
            
            $this->smarty->assign(array(
                'total_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
                'responseCode' => $responseCode,
                'customer_name'=>$customer->firstname. ' '.$customer->lastname ,
                'card_number'=>Tools::getValue('CardNumber'),
                'ps_reference'=>$params['objOrder']->reference,
                'email'=>$customer->email,
                'id_order' => $params['objOrder']->id
            ));
            
            if (isset($params['objOrder']->reference) && !empty($params['objOrder']->reference))
                $this->smarty->assign('reference', $params['objOrder']->reference);
        } else
            $this->smarty->assign('responseCode', $responseCode);
        
        return $this->display(__FILE__, 'payment_return.tpl');
    }

    public function checkCurrency($cart) {
        error_log("netpayprestashop -> checkCurrency()", 0);
        $currency_order = new Currency((int) ($cart->id_currency));
        $currencies_module = $this->getCurrency((int) $cart->id_currency);

        if (is_array($currencies_module))
            foreach ($currencies_module as $currency_module)
                if ($currency_order->id == $currency_module['id_currency'])
                    return true;
        return false;
    }
    
    public function processPayment(){
        error_log("netpayprestashop -> processPayment()", 0);
        error_log("netpayprestashop-validation -> : controller". json_encode($this->context->cart), 0);
    }
    
    private function __createPendingNetPayState() {
        $state = new OrderState();
        $languages = Language::getLanguages();
        $names = array();

        foreach ($languages as $lang) {
            $names[$lang['id_lang']] = 'Pago mediante NetPay Pendiente';
        }

        $state->name = $names;
        $state->color = '#30a0df';
        $state->module_name = 'netpayprestashop';
        $state->logable = true;
        $state->unremovable = true;
        $state->paid = true;
        $templ = array();

        foreach ($languages as $lang) {
            $templ[$lang['id_lang']] = 'netpayprestashop';
        }

        $state->template = $templ;
        if ($state->save()) {//PENDING_NETPAY_PAYMENT
            Configuration::updateValue('PENDING_NETPAY_PAYMENT', $state->id);
        } else {
            return false;
        }
        return true;
    }
        private function __createNetPayAcceptedState() {
        $state = new OrderState();
        $languages = Language::getLanguages();
        $names = array();

        foreach ($languages as $lang) {
            $names[$lang['id_lang']] = 'Pago mediante NetPay Aceptado';
        }

        $state->name = $names;
        $state->color = '#32CD32';
        $state->module_name = 'netpayprestashop';
        $state->invoice = true;
        $state->pdf_invoice = true;
        $state->logable = true;
        $state->unremovable = true;
        $state->paid = true;
        
        $templ = array();

        foreach ($languages as $lang) {
            $templ[$lang['id_lang']] = 'netpayprestashop';
        }

        $state->template = $templ;
        if ($state->save()) {
            Configuration::updateValue('ACCEPTED_NETPAY_PAYMENT', $state->id);
        } else {
            return false;
        }
        return true;
    }

}
